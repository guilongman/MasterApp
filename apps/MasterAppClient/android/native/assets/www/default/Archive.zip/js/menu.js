$(document).ready(function(){
	$(".button-collapse").sideNav();
	  //$('.collapsible').collapsible();
});